
package shop2;
import java.util.Scanner;

public class Products2 
{
    private double monsats;
    private double netto;
    private String namn;
    private String artical;
    
public Products2()//Kom ihåg om du ska dekalera obejekt i huvud klass måste du förste deklarera den i classen
{
    this.monsats=0.0;
    this.netto= 0.0;
    this.namn="";
    this.artical="";
}

public String getNamn(){
    return this.namn;
}

public double getMonsats(){
    return this.monsats;
}

public double getNetto(){
    return this.netto;
}

public double getBrutto(){
    return this.netto+this.netto*this.monsats;
}

public double getMoms(){
    return this.netto*this.monsats;
}

public void setNamn(String namn){
    this.namn =namn;
}

public void setMons( double monsats ){
    this.monsats = monsats;
}
public void setNetto(double netto){
    this.netto= netto;
}

public void setArtical(String artical){
    this.artical=artical;
}


public void setArtical2(String artical){
    int k;
    Scanner scan = new Scanner(System.in);
    do{
        System.out.println();
        System.out.println("detta är artikel valen du har");
        System.out.println("1 läsa/ 6%");
        System.out.println("2 mat/ 12%");
        System.out.println("3 nöje/ 25%");
        k=0;//do while som tvingar personer att välja mellan 1-3
        int i=scan.nextInt();
        switch(i){
            
            case 1:
                this.artical="läsa";
                this.monsats=0.06;
            break;
        
            case 2:
                this.artical="mat";
                this.monsats=0.12;
            break;
    
            case 3:    
                this.artical="nöje";
                this.monsats=0.25;
            break;
    
            default:
                System.out.println("kan inte läsa den siffran");
                k=1;
        }
    }while(k==1);
}

@Override
public String toString(){
    return (namn + "\t"+artical+"\t"+monsats+"\t"+this.getMoms()+"\t"+netto+"\t"+this.getBrutto());
}
}

