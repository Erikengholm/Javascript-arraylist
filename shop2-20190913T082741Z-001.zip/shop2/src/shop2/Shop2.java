
package shop2;
import java.util.Scanner;
import java.util.ArrayList;

public class Shop2 {

    public static void main(String[] args) {
        int i,k,z,list=0;
        double tm=0,tb=0;
        ArrayList<Products2> product = new ArrayList();
        Scanner scan = new Scanner(System.in);

        do{
            //  dom här två talen ser till att du hamnar i en loop som gör det möljigt att skapa om producten flera gånger  
            z=0;
            k=0;
            // add måste användas for att lägga till ny och obejectet kan inte ha några förbestämda varabler
            
            product.add(new Products2());
            System.out.println("skriv in vilket namn du vill ge till artikeln");
            product.get(list).setNamn(scan.next());// lägger till ett namn på producten
            
            System.out.println("välj priset som artikeln ska ha genom att skriva in det");
            product.get(list).setNetto(scan.nextInt());//sätter priset på prudokten
            
            System.out.println("vilket artikel är det du lägger till och vad för mons ska den ha");
            product.get(list).setArtical2("k");//satt priset på prudokten
            
            do{
                System.out.println();
                System.out.println("om du vill veta något mera skriv bara in den raden som du vill veta");
                System.out.println("1 bruto priset");
                System.out.println("2 mons priset");
                System.out.println("3 allting");
                System.out.println("4 jag vill göra en ny producten");
                System.out.println("5 allting är färdig");
                System.out.println();
                
                i=scan.nextInt();
                
                switch(i) {//switch är en val system
                    
                    case 1:// om (i = 1)
                        System.out.println("du får "+product.get(list).getBrutto()+" i brutto");
                    break;
                    
                    case 2:  // om (i = 2)
                        System.out.println("du får "+product.get(list).getMoms()+" i moms");
                    break;
                    
                    case 3:  // om ( i = 3)
                        System.out.println("detta är allting jag vet om artikeln"+product.get(list));
                    break;
                    
                    case 4:  // om ( i = 4)
                        k=1;
                    //berättare att do whilen ska hålla os kvar vid switchen
                    break;
                    
                    case 5:  // om i = 5)
                        z=1;
                        k=1;
                    //berättare att båda do whilena ska låta oss lämna hela koden
                    break;
                    
                    default:
                }
            
            }while(k==0);
            
            list++;
        
        }while(z==0);
        
        System.out.println("namn |  artikeltyp   |   moms     |     monstats     |   nettopris   | bruto");
        
        for (int index=0; index<product.size();index++){
            // pa arreylist maste du använda size istället för length
            System.out.println(product.get(index));
        }
        
        for (int counter=0; counter<product.size();counter++){
            tb+=product.get(counter).getBrutto();
            tm+=product.get(counter).getMoms();
        }
        
        System.out.println("den tottala brutto priset är "+tb);
        System.out.println("den tottala momsen är "+tm);
        
    }
}
